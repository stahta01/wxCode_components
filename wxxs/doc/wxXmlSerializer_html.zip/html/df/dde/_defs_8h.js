var _defs_8h =
[
    [ "WXDLLIMPEXP_DATA_XS", "df/dde/_defs_8h.html#ad995e62e38d3b609d5dd9fd03e1559b0", null ],
    [ "WXDLLIMPEXP_XS", "df/dde/_defs_8h.html#a486f461b5623485ccd8c2ca6ca7db844", null ]
];