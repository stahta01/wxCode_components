var namespaces =
[
    [ "wxXS", "de/d57/namespacewx_x_s.html", "de/d57/namespacewx_x_s" ]
];