var searchData=
[
  ['searchbfs',['searchBFS',['../de/d26/classxs_serializable.html#a57665636f39e6b8bcf4e20662958c48dab1ea37793c059041b5b4fad89f9647a3',1,'xsSerializable']]],
  ['searchdfs',['searchDFS',['../de/d26/classxs_serializable.html#a57665636f39e6b8bcf4e20662958c48da30647bfe21ebd9f4d1d12a83479a1a2f',1,'xsSerializable']]],
  ['searchmode',['SEARCHMODE',['../de/d26/classxs_serializable.html#a57665636f39e6b8bcf4e20662958c48d',1,'xsSerializable']]],
  ['serializablelist',['SerializableList',['../da/ded/_property_i_o_8h.html#a6100966c6ebe42dc1c89d8534dedd195',1,'PropertyIO.h']]],
  ['serialize',['Serialize',['../de/d26/classxs_serializable.html#a28c818d914bc3154569a80ec20815191',1,'xsSerializable']]],
  ['serializeobject',['SerializeObject',['../de/d26/classxs_serializable.html#a4627e12622d828408e975ce507c7e065',1,'xsSerializable']]],
  ['serializeobjects',['SerializeObjects',['../df/dfd/classwx_xml_serializer.html#a597c1345b4b6e6108c4aea0bac545e48',1,'wxXmlSerializer']]],
  ['serializetoxml',['SerializeToXml',['../df/dfd/classwx_xml_serializer.html#a7b347387848cbda2d41530694d91afdb',1,'wxXmlSerializer::SerializeToXml(const wxString &amp;file, bool withroot=false)'],['../df/dfd/classwx_xml_serializer.html#af10f3cd6f028a99d08b4f47250cb2872',1,'wxXmlSerializer::SerializeToXml(wxOutputStream &amp;outstream, bool withroot=false)']]],
  ['setid',['SetId',['../de/d26/classxs_serializable.html#a2919ab7e8f2c3bda5dce46ce09141c81',1,'xsSerializable']]],
  ['setparent',['SetParent',['../de/d26/classxs_serializable.html#a12c08da183a4f109c3f0948e545c1a4b',1,'xsSerializable']]],
  ['setparentmanager',['SetParentManager',['../de/d26/classxs_serializable.html#abcf05f1827ca36254ad1686c786e9fa9',1,'xsSerializable']]],
  ['setrootitem',['SetRootItem',['../df/dfd/classwx_xml_serializer.html#a9f60b88bcbdf6d42d44e97aaff8efd21',1,'wxXmlSerializer']]],
  ['setserializerowner',['SetSerializerOwner',['../df/dfd/classwx_xml_serializer.html#a32170c2c5feddb1be8fccd41a5769cf4',1,'wxXmlSerializer']]],
  ['setserializerrootname',['SetSerializerRootName',['../df/dfd/classwx_xml_serializer.html#acabd4a1f46c3ceb17189d55fae37b8bd',1,'wxXmlSerializer']]],
  ['setserializerversion',['SetSerializerVersion',['../df/dfd/classwx_xml_serializer.html#a3f79e7d964e9ec4bcbdb94ca0b128708',1,'wxXmlSerializer']]],
  ['setvaluestr',['SetValueStr',['../df/d41/classxs_property_i_o.html#a2b8bd2e449ab4e63c6bebf0920208703',1,'xsPropertyIO']]],
  ['simple_2dlist_2dsample_2etxt',['simple-list-sample.txt',['../d1/d0f/simple-list-sample_8txt.html',1,'']]],
  ['simple_2dtree_2dsample_2etxt',['simple-tree-sample.txt',['../d8/d46/simple-tree-sample_8txt.html',1,'']]],
  ['static_2dsettings_2dsample_2etxt',['static-settings-sample.txt',['../d7/d0b/static-settings-sample_8txt.html',1,'']]]
];
