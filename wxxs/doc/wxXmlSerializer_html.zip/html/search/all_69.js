var searchData=
[
  ['initchild',['InitChild',['../de/d26/classxs_serializable.html#ade7e7ee46c264a99978e99ee2a17bdb1',1,'xsSerializable']]],
  ['initializealliohandlers',['InitializeAllIOHandlers',['../df/dfd/classwx_xml_serializer.html#aa34840f14995719db4fb3308b1120e06',1,'wxXmlSerializer']]],
  ['insertchild',['InsertChild',['../de/d26/classxs_serializable.html#a7c8b5043e0535d1fa8816b8659885d5f',1,'xsSerializable']]],
  ['iscloned',['IsCloned',['../df/dfd/classwx_xml_serializer.html#a6d5ce5d72024a74cd8a6ff2a4f1a9fd2',1,'wxXmlSerializer']]],
  ['iscloningenabled',['IsCloningEnabled',['../de/d26/classxs_serializable.html#adb8cc66c384423437811673bf4891cab',1,'xsSerializable']]],
  ['isidused',['IsIdUsed',['../df/dfd/classwx_xml_serializer.html#a489ab1eac65553dc54ffe254533f29bd',1,'wxXmlSerializer']]],
  ['ispropertyserialized',['IsPropertySerialized',['../de/d26/classxs_serializable.html#ac5510c5a5b0d24251a67dca405c8d31e',1,'xsSerializable']]],
  ['isserialized',['IsSerialized',['../de/d26/classxs_serializable.html#aa1e5c8dc4864b6011af0c2e29718d4c7',1,'xsSerializable']]]
];
