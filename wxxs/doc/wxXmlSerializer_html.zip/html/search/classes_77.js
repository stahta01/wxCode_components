var searchData=
[
  ['wxxmlserializer',['wxXmlSerializer',['../df/dfd/classwx_xml_serializer.html',1,'']]]
];
