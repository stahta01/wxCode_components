var searchData=
[
  ['haschildren',['HasChildren',['../de/d26/classxs_serializable.html#aa2a3e2a884aded3299d79773ecd6f883',1,'xsSerializable']]]
];
