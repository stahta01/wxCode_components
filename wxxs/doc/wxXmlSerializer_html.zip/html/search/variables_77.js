var searchData=
[
  ['wxxmlserializer',['wxXmlSerializer',['../de/dbb/_xml_serializer_8h.html#a33b49ec4bb4131b5029dcfc17be3f3cc',1,'XmlSerializer.h']]]
];
