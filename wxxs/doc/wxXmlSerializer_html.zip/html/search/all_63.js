var searchData=
[
  ['cleariohandlers',['ClearIOHandlers',['../df/dfd/classwx_xml_serializer.html#a7d3c18d9b46f85c14547fbf5ef87e6f4',1,'wxXmlSerializer']]],
  ['contains',['Contains',['../df/dfd/classwx_xml_serializer.html#a046eff3574bbb59957021c7241b50515',1,'wxXmlSerializer::Contains(xsSerializable *object) const '],['../df/dfd/classwx_xml_serializer.html#a6041e332ab3cc95a0c8a3c83eeb1461c',1,'wxXmlSerializer::Contains(wxClassInfo *type)']]],
  ['copyitems',['CopyItems',['../df/dfd/classwx_xml_serializer.html#ab0e0f99ee9b2de7c6c53ca4fb2b588d0',1,'wxXmlSerializer']]],
  ['custom_2ddata_2dsample_2etxt',['custom-data-sample.txt',['../d9/df8/custom-data-sample_8txt.html',1,'']]]
];
