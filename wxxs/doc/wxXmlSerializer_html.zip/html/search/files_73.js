var searchData=
[
  ['simple_2dlist_2dsample_2etxt',['simple-list-sample.txt',['../d1/d0f/simple-list-sample_8txt.html',1,'']]],
  ['simple_2dtree_2dsample_2etxt',['simple-tree-sample.txt',['../d8/d46/simple-tree-sample_8txt.html',1,'']]],
  ['static_2dsettings_2dsample_2etxt',['static-settings-sample.txt',['../d7/d0b/static-settings-sample_8txt.html',1,'']]]
];
