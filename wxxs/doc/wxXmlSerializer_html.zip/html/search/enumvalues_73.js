var searchData=
[
  ['searchbfs',['searchBFS',['../de/d26/classxs_serializable.html#a57665636f39e6b8bcf4e20662958c48dab1ea37793c059041b5b4fad89f9647a3',1,'xsSerializable']]],
  ['searchdfs',['searchDFS',['../de/d26/classxs_serializable.html#a57665636f39e6b8bcf4e20662958c48da30647bfe21ebd9f4d1d12a83479a1a2f',1,'xsSerializable']]]
];
