var searchData=
[
  ['declare_5fdynamic_5fclass',['DECLARE_DYNAMIC_CLASS',['../df/d41/classxs_property_i_o.html#ae945b1e12096c714e0ab141d8d4d8720',1,'xsPropertyIO::DECLARE_DYNAMIC_CLASS()'],['../db/ddf/classxs_property.html#a552ec618213d94187e77bc9de3725703',1,'xsProperty::DECLARE_DYNAMIC_CLASS()']]],
  ['deserialize',['Deserialize',['../de/d26/classxs_serializable.html#a20cf1513b24192f4da90eb84b2a5f714',1,'xsSerializable']]],
  ['deserializefromxml',['DeserializeFromXml',['../df/dfd/classwx_xml_serializer.html#a18367208273152938accde87f8715aca',1,'wxXmlSerializer::DeserializeFromXml(const wxString &amp;file)'],['../df/dfd/classwx_xml_serializer.html#a33840b9468e90828d2f7381d02f4b1d7',1,'wxXmlSerializer::DeserializeFromXml(wxInputStream &amp;instream)']]],
  ['deserializeobject',['DeserializeObject',['../de/d26/classxs_serializable.html#a039a37a487889bfc20c8b1f27deb2d7f',1,'xsSerializable']]],
  ['deserializeobjects',['DeserializeObjects',['../df/dfd/classwx_xml_serializer.html#a6df0c4462b7166d7639ee75720315881',1,'wxXmlSerializer']]]
];
