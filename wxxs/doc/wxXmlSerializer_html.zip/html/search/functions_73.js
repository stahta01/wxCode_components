var searchData=
[
  ['serialize',['Serialize',['../de/d26/classxs_serializable.html#a28c818d914bc3154569a80ec20815191',1,'xsSerializable']]],
  ['serializeobject',['SerializeObject',['../de/d26/classxs_serializable.html#a4627e12622d828408e975ce507c7e065',1,'xsSerializable']]],
  ['serializeobjects',['SerializeObjects',['../df/dfd/classwx_xml_serializer.html#a597c1345b4b6e6108c4aea0bac545e48',1,'wxXmlSerializer']]],
  ['serializetoxml',['SerializeToXml',['../df/dfd/classwx_xml_serializer.html#a7b347387848cbda2d41530694d91afdb',1,'wxXmlSerializer::SerializeToXml(const wxString &amp;file, bool withroot=false)'],['../df/dfd/classwx_xml_serializer.html#af10f3cd6f028a99d08b4f47250cb2872',1,'wxXmlSerializer::SerializeToXml(wxOutputStream &amp;outstream, bool withroot=false)']]],
  ['setid',['SetId',['../de/d26/classxs_serializable.html#a2919ab7e8f2c3bda5dce46ce09141c81',1,'xsSerializable']]],
  ['setparent',['SetParent',['../de/d26/classxs_serializable.html#a12c08da183a4f109c3f0948e545c1a4b',1,'xsSerializable']]],
  ['setparentmanager',['SetParentManager',['../de/d26/classxs_serializable.html#abcf05f1827ca36254ad1686c786e9fa9',1,'xsSerializable']]],
  ['setrootitem',['SetRootItem',['../df/dfd/classwx_xml_serializer.html#a9f60b88bcbdf6d42d44e97aaff8efd21',1,'wxXmlSerializer']]],
  ['setserializerowner',['SetSerializerOwner',['../df/dfd/classwx_xml_serializer.html#a32170c2c5feddb1be8fccd41a5769cf4',1,'wxXmlSerializer']]],
  ['setserializerrootname',['SetSerializerRootName',['../df/dfd/classwx_xml_serializer.html#acabd4a1f46c3ceb17189d55fae37b8bd',1,'wxXmlSerializer']]],
  ['setserializerversion',['SetSerializerVersion',['../df/dfd/classwx_xml_serializer.html#a3f79e7d964e9ec4bcbdb94ca0b128708',1,'wxXmlSerializer']]],
  ['setvaluestr',['SetValueStr',['../df/d41/classxs_property_i_o.html#a2b8bd2e449ab4e63c6bebf0920208703',1,'xsPropertyIO']]]
];
