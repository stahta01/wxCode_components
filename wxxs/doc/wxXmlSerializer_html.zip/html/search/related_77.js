var searchData=
[
  ['wxxmlserializer',['wxXmlSerializer',['../de/d26/classxs_serializable.html#ac53f74d90283b86359f3b8f895d56580',1,'xsSerializable']]]
];
