var files =
[
    [ "Defs.h", "df/dde/_defs_8h.html", "df/dde/_defs_8h" ],
    [ "PropertyIO.h", "da/ded/_property_i_o_8h.html", "da/ded/_property_i_o_8h" ],
    [ "XmlSerializer.h", "de/dbb/_xml_serializer_8h.html", "de/dbb/_xml_serializer_8h" ]
];