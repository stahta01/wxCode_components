var annotated =
[
    [ "wxXmlSerializer", "df/dfd/classwx_xml_serializer.html", "df/dfd/classwx_xml_serializer" ],
    [ "xsProperty", "db/ddf/classxs_property.html", "db/ddf/classxs_property" ],
    [ "xsPropertyIO", "df/d41/classxs_property_i_o.html", "df/d41/classxs_property_i_o" ],
    [ "xsSerializable", "de/d26/classxs_serializable.html", "de/d26/classxs_serializable" ]
];