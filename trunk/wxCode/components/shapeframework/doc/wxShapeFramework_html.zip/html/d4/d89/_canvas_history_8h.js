var _canvas_history_8h =
[
    [ "sfDEFAULT_MAX_CANVAS_STATES", "d4/d89/_canvas_history_8h.html#ac71268feff914d5fd90d79810675ae9e", null ],
    [ "wxSFShapeCanvas", "d4/d89/_canvas_history_8h.html#aef4456c4a2231503620b8a48d0bfa059", null ]
];