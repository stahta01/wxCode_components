var _diagram_manager_8h =
[
    [ "serINCLUDE_PARENTS", "d4/d67/_diagram_manager_8h.html#aa69061e91fc28b49b6bf74f1f86394f2", null ],
    [ "serWITHOUT_PARENTS", "d4/d67/_diagram_manager_8h.html#aaf0b736bd54cbef6e8d3ef6a190c7840", null ],
    [ "sfDONT_INITIALIZE", "d4/d67/_diagram_manager_8h.html#a5355fc61ab0079ea74b61a99c0e9f929", null ],
    [ "sfINITIALIZE", "d4/d67/_diagram_manager_8h.html#ab4f86fb9a60084ea42f62beefc0b0e2a", null ],
    [ "WX_DECLARE_LIST", "d4/d67/_diagram_manager_8h.html#a8ba3d62f7be6917a2ba3005681f9ea63", null ]
];