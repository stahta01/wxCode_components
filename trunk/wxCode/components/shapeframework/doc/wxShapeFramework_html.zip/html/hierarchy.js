var hierarchy =
[
    [ "EventSink", "d8/daf/class_event_sink.html", null ],
    [ "IDPair", "d4/d5f/class_i_d_pair.html", null ],
    [ "wxSFAutoLayout", "da/df4/classwx_s_f_auto_layout.html", null ],
    [ "wxSFCanvasDropTarget", "da/d2a/classwx_s_f_canvas_drop_target.html", null ],
    [ "wxSFCanvasHistory", "d8/d5f/classwx_s_f_canvas_history.html", null ],
    [ "wxSFCanvasState", "d7/d2d/classwx_s_f_canvas_state.html", null ],
    [ "wxSFContentCtrl", "d1/d6a/classwx_s_f_content_ctrl.html", null ],
    [ "wxSFDetachedContentCtrl", "dd/de1/classwx_s_f_detached_content_ctrl.html", null ],
    [ "wxSFLayoutAlgorithm", "d9/d29/classwx_s_f_layout_algorithm.html", [
      [ "wxSFLayoutCircle", "d8/d1e/classwx_s_f_layout_circle.html", null ],
      [ "wxSFLayoutHorizontalTree", "d0/d47/classwx_s_f_layout_horizontal_tree.html", null ],
      [ "wxSFLayoutMesh", "d9/dc3/classwx_s_f_layout_mesh.html", null ],
      [ "wxSFLayoutVerticalTree", "db/d25/classwx_s_f_layout_vertical_tree.html", null ]
    ] ],
    [ "wxSFPrintout", "d8/d77/classwx_s_f_printout.html", null ],
    [ "wxSFScaledDC", "d5/d50/classwx_s_f_scaled_d_c.html", null ],
    [ "wxSFShapeCanvas", "db/d44/classwx_s_f_shape_canvas.html", null ],
    [ "wxSFShapeChildDropEvent", "db/d44/classwx_s_f_shape_child_drop_event.html", null ],
    [ "wxSFShapeDataObject", "dd/d31/classwx_s_f_shape_data_object.html", null ],
    [ "wxSFShapeDropEvent", "d9/de9/classwx_s_f_shape_drop_event.html", null ],
    [ "wxSFShapeEvent", "d6/d43/classwx_s_f_shape_event.html", null ],
    [ "wxSFShapeHandle", "d9/dde/classwx_s_f_shape_handle.html", null ],
    [ "wxSFShapeHandleEvent", "df/d94/classwx_s_f_shape_handle_event.html", null ],
    [ "wxSFShapeKeyEvent", "d7/dc8/classwx_s_f_shape_key_event.html", null ],
    [ "wxSFShapeMouseEvent", "d8/d2f/classwx_s_f_shape_mouse_event.html", null ],
    [ "wxSFShapePasteEvent", "d0/d11/classwx_s_f_shape_paste_event.html", null ],
    [ "wxSFShapeTextEvent", "d9/dad/classwx_s_f_shape_text_event.html", null ],
    [ "wxSFThumbnail", "df/dc2/classwx_s_f_thumbnail.html", null ],
    [ "wxXmlSerializer", "df/dfd/classwx_xml_serializer.html", [
      [ "wxSFDiagramManager", "d2/d22/classwx_s_f_diagram_manager.html", null ]
    ] ],
    [ "xsProperty", "db/ddf/classxs_property.html", null ],
    [ "xsPropertyIO", "df/d41/classxs_property_i_o.html", null ],
    [ "xsSerializable", "de/d26/classxs_serializable.html", [
      [ "wxSFArrowBase", "db/ddd/classwx_s_f_arrow_base.html", [
        [ "wxSFOpenArrow", "d6/dab/classwx_s_f_open_arrow.html", null ],
        [ "wxSFSolidArrow", "d7/d98/classwx_s_f_solid_arrow.html", [
          [ "wxSFCircleArrow", "da/d96/classwx_s_f_circle_arrow.html", null ],
          [ "wxSFDiamondArrow", "d5/d7b/classwx_s_f_diamond_arrow.html", null ]
        ] ]
      ] ],
      [ "wxSFCanvasSettings", "d6/d7a/classwx_s_f_canvas_settings.html", null ],
      [ "wxSFConnectionPoint", "d5/de9/classwx_s_f_connection_point.html", null ],
      [ "wxSFShapeBase", "da/d88/classwx_s_f_shape_base.html", [
        [ "wxSFLineShape", "d7/d05/classwx_s_f_line_shape.html", [
          [ "wxSFCurveShape", "d2/dfb/classwx_s_f_curve_shape.html", null ],
          [ "wxSFOrthoLineShape", "d7/d4e/classwx_s_f_ortho_line_shape.html", [
            [ "wxSFRoundOrthoLineShape", "d3/d82/classwx_s_f_round_ortho_line_shape.html", null ]
          ] ]
        ] ],
        [ "wxSFRectShape", "db/d0e/classwx_s_f_rect_shape.html", [
          [ "wxSFBitmapShape", "df/d4c/classwx_s_f_bitmap_shape.html", null ],
          [ "wxSFControlShape", "d0/d60/classwx_s_f_control_shape.html", null ],
          [ "wxSFEllipseShape", "df/d3f/classwx_s_f_ellipse_shape.html", null ],
          [ "wxSFGridShape", "dd/d32/classwx_s_f_grid_shape.html", [
            [ "wxSFFlexGridShape", "dc/d15/classwx_s_f_flex_grid_shape.html", null ]
          ] ],
          [ "wxSFMultiSelRect", "d8/d71/classwx_s_f_multi_sel_rect.html", null ],
          [ "wxSFPolygonShape", "d9/dbd/classwx_s_f_polygon_shape.html", [
            [ "wxSFDiamondShape", "d4/d6a/classwx_s_f_diamond_shape.html", null ]
          ] ],
          [ "wxSFRoundRectShape", "d2/d9a/classwx_s_f_round_rect_shape.html", null ],
          [ "wxSFSquareShape", "d3/df7/classwx_s_f_square_shape.html", [
            [ "wxSFCircleShape", "db/d30/classwx_s_f_circle_shape.html", null ]
          ] ],
          [ "wxSFTextShape", "de/d95/classwx_s_f_text_shape.html", [
            [ "wxSFEditTextShape", "db/d8d/classwx_s_f_edit_text_shape.html", null ]
          ] ]
        ] ]
      ] ]
    ] ]
];