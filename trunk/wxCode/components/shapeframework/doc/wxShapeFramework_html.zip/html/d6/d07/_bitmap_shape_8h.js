var _bitmap_shape_8h =
[
    [ "sfdvBITMAPSHAPE_SCALEIMAGE", "d6/d07/_bitmap_shape_8h.html#abb1c351b13e064807b187853e9374930", null ],
    [ "sfdvBITMAPSHAPE_XPMDATA", "d6/d07/_bitmap_shape_8h.html#a8e2c6de03ec78fb8f649bf5314a24484", null ]
];