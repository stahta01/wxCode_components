var classwx_s_f_canvas_settings =
[
    [ "wxSFCanvasSettings", "d6/d7a/classwx_s_f_canvas_settings.html#a2b187d15c00f0cc23ba9c98996894833", null ],
    [ "DECLARE_DYNAMIC_CLASS", "d6/d7a/classwx_s_f_canvas_settings.html#ab51611d7dbb3c2807c197aa9e71fedc3", null ],
    [ "m_arrAcceptedShapes", "d6/d7a/classwx_s_f_canvas_settings.html#a6e586e5d180cf853a1622a3b5354f00a", null ],
    [ "m_nBackgroundColor", "d6/d7a/classwx_s_f_canvas_settings.html#a5064fdcf642f79a06e1e8c7b44cd5ad6", null ],
    [ "m_nCommonHoverColor", "d6/d7a/classwx_s_f_canvas_settings.html#ae7df16ce7f50dc3b5c130206eec6e0e1", null ],
    [ "m_nGradientFrom", "d6/d7a/classwx_s_f_canvas_settings.html#ad35194790109cfee681b9caace7b9b6c", null ],
    [ "m_nGradientTo", "d6/d7a/classwx_s_f_canvas_settings.html#aaf5b1fe02b42971156094d5cad4edb93", null ],
    [ "m_nGridColor", "d6/d7a/classwx_s_f_canvas_settings.html#aba2fa11bee30766018e2463c9c827041", null ],
    [ "m_nGridLineMult", "d6/d7a/classwx_s_f_canvas_settings.html#ab80b5fe27498d7fb5747867ea95b1ab0", null ],
    [ "m_nGridSize", "d6/d7a/classwx_s_f_canvas_settings.html#a16c9d4ef46978fa28b647229e933ef40", null ],
    [ "m_nGridStyle", "d6/d7a/classwx_s_f_canvas_settings.html#a391bdba71384938dc7b98c4988708566", null ],
    [ "m_nMaxScale", "d6/d7a/classwx_s_f_canvas_settings.html#a8a22b88d626a661aa39a7c03e0be7ac8", null ],
    [ "m_nMinScale", "d6/d7a/classwx_s_f_canvas_settings.html#a501a3c870fe33beabb4f371f12fa1dab", null ],
    [ "m_nPrintHAlign", "d6/d7a/classwx_s_f_canvas_settings.html#a78eb2239fcf59440a27a8bbfea8ce2c7", null ],
    [ "m_nPrintMode", "d6/d7a/classwx_s_f_canvas_settings.html#a488f9d6a665babfe93781bb097ecd5f1", null ],
    [ "m_nPrintVAlign", "d6/d7a/classwx_s_f_canvas_settings.html#ac1700969503d0e30cbb20046c39fbc99", null ],
    [ "m_nScale", "d6/d7a/classwx_s_f_canvas_settings.html#ac6cc9e9420a4e01c2fc098e9bf429714", null ],
    [ "m_nShadowOffset", "d6/d7a/classwx_s_f_canvas_settings.html#a6ab57cdbd4a27a4deb8d59d7289e8aec", null ],
    [ "m_nStyle", "d6/d7a/classwx_s_f_canvas_settings.html#aab824574fa1f3347c75dad5b871049c3", null ],
    [ "m_ShadowFill", "d6/d7a/classwx_s_f_canvas_settings.html#af0645d3d8b80e787464d86f7935374b5", null ]
];