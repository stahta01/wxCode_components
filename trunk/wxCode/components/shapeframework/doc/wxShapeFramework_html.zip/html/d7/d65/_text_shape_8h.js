var _text_shape_8h =
[
    [ "sfdvTEXTSHAPE_FONT", "d7/d65/_text_shape_8h.html#a5618808258f5cdba4abbc1c57091c5b3", null ],
    [ "sfdvTEXTSHAPE_TEXTCOLOR", "d7/d65/_text_shape_8h.html#a4d3840c8c56183512d870ba27682cd1a", null ]
];