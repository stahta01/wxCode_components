var _shape_dockpoint_8h =
[
    [ "sfdvCONNPOINT_RELPOS", "d7/d41/_shape_dockpoint_8h.html#a0bcc6d817f9bc60b9fecc6cf09af9e17", null ],
    [ "wxSFShapeBase", "d7/d41/_shape_dockpoint_8h.html#a625b2b504e999722ca583079656b66ad", null ]
];