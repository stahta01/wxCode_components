var classwx_s_f_ellipse_shape =
[
    [ "wxSFEllipseShape", "df/d3f/classwx_s_f_ellipse_shape.html#a145c159f91efba329e818aa465ea67b9", null ],
    [ "wxSFEllipseShape", "df/d3f/classwx_s_f_ellipse_shape.html#ad82a1d4da9f27da5f9948ad790b7523f", null ],
    [ "wxSFEllipseShape", "df/d3f/classwx_s_f_ellipse_shape.html#a60a88d5b3e83e2952a14afe178784fb3", null ],
    [ "~wxSFEllipseShape", "df/d3f/classwx_s_f_ellipse_shape.html#a984b43841742a199205022ac0f705f18", null ],
    [ "Contains", "df/d3f/classwx_s_f_ellipse_shape.html#a7a47ba6e8cca30f7d1272b1f4e0c1130", null ],
    [ "DrawHighlighted", "df/d3f/classwx_s_f_ellipse_shape.html#a5e6d72a29fa6af1b1f3b5abf38b2feb3", null ],
    [ "DrawHover", "df/d3f/classwx_s_f_ellipse_shape.html#a2bad6cbaa5dcebad231687a1a7fb836e", null ],
    [ "DrawNormal", "df/d3f/classwx_s_f_ellipse_shape.html#a5074581b4b5c04e2cf47bea56ad75ae3", null ],
    [ "DrawShadow", "df/d3f/classwx_s_f_ellipse_shape.html#ae5091978cac20b89eb487be22901c24b", null ],
    [ "GetBorderPoint", "df/d3f/classwx_s_f_ellipse_shape.html#a85bc26360e692fbdde306d157d54c463", null ],
    [ "XS_DECLARE_CLONABLE_CLASS", "df/d3f/classwx_s_f_ellipse_shape.html#a976bbcbeacf49e6d8945a2759d7ed7c3", null ]
];