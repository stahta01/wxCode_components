var globals_dup =
[
    [ "c", "globals.html", null ],
    [ "e", "globals_0x65.html", null ],
    [ "g", "globals_0x67.html", null ],
    [ "m", "globals_0x6d.html", null ],
    [ "s", "globals_0x73.html", null ],
    [ "w", "globals_0x77.html", null ],
    [ "x", "globals_0x78.html", null ]
];