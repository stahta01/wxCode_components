var classwx_s_f_detached_content_ctrl =
[
    [ "wxSFDetachedContentCtrl", "dd/de1/classwx_s_f_detached_content_ctrl.html#af612de4bc5718c5ff65f3064f6360c98", null ],
    [ "~wxSFDetachedContentCtrl", "dd/de1/classwx_s_f_detached_content_ctrl.html#a228c7947f4c83e111e9734103977092d", null ],
    [ "GetContent", "dd/de1/classwx_s_f_detached_content_ctrl.html#a6b607c79c3bac1984ebf419481d508f1", null ],
    [ "SetContent", "dd/de1/classwx_s_f_detached_content_ctrl.html#ab125ea34a125537e0f41162f8bfffd3e", null ],
    [ "m_pText", "dd/de1/classwx_s_f_detached_content_ctrl.html#a04dd2d9649d4f86956f2f3b4084b522f", null ]
];