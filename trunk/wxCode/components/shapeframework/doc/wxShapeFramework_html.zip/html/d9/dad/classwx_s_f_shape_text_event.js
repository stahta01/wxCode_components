var classwx_s_f_shape_text_event =
[
    [ "wxSFShapeTextEvent", "d9/dad/classwx_s_f_shape_text_event.html#ac01d04fc1bfa9de7e14648c62b1014d1", null ],
    [ "wxSFShapeTextEvent", "d9/dad/classwx_s_f_shape_text_event.html#a88cba054b7f1f67206965e0271e3d942", null ],
    [ "~wxSFShapeTextEvent", "d9/dad/classwx_s_f_shape_text_event.html#a02042cc7106cb6775b301e9478a0347d", null ],
    [ "Clone", "d9/dad/classwx_s_f_shape_text_event.html#a7100365627ff1901478d509ce307d0ef", null ],
    [ "GetShape", "d9/dad/classwx_s_f_shape_text_event.html#a9f517a201c8011c9ffab9dc92e6ded6f", null ],
    [ "GetText", "d9/dad/classwx_s_f_shape_text_event.html#a2cbf02921981d482f682165ef6931b86", null ],
    [ "SetShape", "d9/dad/classwx_s_f_shape_text_event.html#acd6757da53ef075dd292b577ea61490d", null ],
    [ "SetText", "d9/dad/classwx_s_f_shape_text_event.html#a83132c4deda849c56f7c45cb6294577c", null ],
    [ "m_Shape", "d9/dad/classwx_s_f_shape_text_event.html#a3520a3cb190f5b6f66f8045daa70304e", null ],
    [ "m_Text", "d9/dad/classwx_s_f_shape_text_event.html#a364ce57f47a8f0417b1d6f89d2fbf931", null ]
];