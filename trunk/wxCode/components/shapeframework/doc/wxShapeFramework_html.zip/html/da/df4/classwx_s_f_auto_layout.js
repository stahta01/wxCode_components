var classwx_s_f_auto_layout =
[
    [ "wxSFAutoLayout", "da/df4/classwx_s_f_auto_layout.html#a52b468ff245b2423c7651b22321dc5b6", null ],
    [ "~wxSFAutoLayout", "da/df4/classwx_s_f_auto_layout.html#a6e6eac84d30deb015ea290219aff5dc1", null ],
    [ "CleanUp", "da/df4/classwx_s_f_auto_layout.html#ac0a40cc7357dcaeca2fa96025c684df7", null ],
    [ "GetAlgorithm", "da/df4/classwx_s_f_auto_layout.html#a7e7867c6fa199c4c2fd62f542ff2932e", null ],
    [ "GetRegisteredAlgorithms", "da/df4/classwx_s_f_auto_layout.html#a6f00835ba7bb2d0de7b77ecae6485e90", null ],
    [ "InitializeAllAlgorithms", "da/df4/classwx_s_f_auto_layout.html#a7703fb5d094b7fa0b2ec100fb1d8d7a1", null ],
    [ "Layout", "da/df4/classwx_s_f_auto_layout.html#a4be97e1c0eb694ae406b2c0c34c8328b", null ],
    [ "Layout", "da/df4/classwx_s_f_auto_layout.html#a70ee6a0cbb2e9765820d5629cb5574fd", null ],
    [ "Layout", "da/df4/classwx_s_f_auto_layout.html#a42df8052c8b2572261bf9608d114a5ca", null ],
    [ "RegisterLayoutAlgorithm", "da/df4/classwx_s_f_auto_layout.html#ad6df46976172dba0ebc58c875b1e7624", null ],
    [ "UpdateCanvas", "da/df4/classwx_s_f_auto_layout.html#a0a58e45ec5a3c2ef160cb5279605dfd7", null ],
    [ "m_mapAlgorithms", "da/df4/classwx_s_f_auto_layout.html#a4057801bc0182128928ca2e339c921a2", null ]
];