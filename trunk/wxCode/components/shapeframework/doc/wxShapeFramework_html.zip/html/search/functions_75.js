var searchData=
[
  ['undo',['Undo',['../db/d44/classwx_s_f_shape_canvas.html#ab5be18d4eff43d4b0390cd36a36b27af',1,'wxSFShapeCanvas']]],
  ['uninitgc',['UninitGC',['../d5/d50/classwx_s_f_scaled_d_c.html#acb8a40dc48da27454af754b70c6608c2',1,'wxSFScaledDC']]],
  ['update',['Update',['../d0/d60/classwx_s_f_control_shape.html#a78e39c334fc76a0d00ed06eeff5990b6',1,'wxSFControlShape::Update()'],['../dd/d32/classwx_s_f_grid_shape.html#aeedba75a21efeeb2ebfee2a1bafa83e6',1,'wxSFGridShape::Update()'],['../da/d88/classwx_s_f_shape_base.html#ac1a86cbe3a82c19bd3ed9b26fb87dd35',1,'wxSFShapeBase::Update()'],['../de/d95/classwx_s_f_text_shape.html#a9bdafd136e472bd029331d238a43f676',1,'wxSFTextShape::Update()']]],
  ['updateall',['UpdateAll',['../d2/d22/classwx_s_f_diagram_manager.html#a325d31ac2facf0e8892eb02af1a57251',1,'wxSFDiagramManager']]],
  ['updatecanvas',['UpdateCanvas',['../da/df4/classwx_s_f_auto_layout.html#a0a58e45ec5a3c2ef160cb5279605dfd7',1,'wxSFAutoLayout']]],
  ['updateconnections',['UpdateConnections',['../d2/d22/classwx_s_f_diagram_manager.html#ab48d94198d643313f91017b98136c5f7',1,'wxSFDiagramManager']]],
  ['updatecontrol',['UpdateControl',['../d0/d60/classwx_s_f_control_shape.html#ab26e35717e21cedf3593ac2c12c22d95',1,'wxSFControlShape']]],
  ['updategrids',['UpdateGrids',['../d2/d22/classwx_s_f_diagram_manager.html#a933d3af907933c45f2e9ac2e7eb1f4b3',1,'wxSFDiagramManager']]],
  ['updatemouseevent',['UpdateMouseEvent',['../d8/daf/class_event_sink.html#a006acba50457a005fce3eb805c19715f',1,'EventSink']]],
  ['updatemultieditsize',['UpdateMultieditSize',['../db/d44/classwx_s_f_shape_canvas.html#a052ca63174cf8d45083a3aa8c01f7c4e',1,'wxSFShapeCanvas']]],
  ['updaterectsize',['UpdateRectSize',['../de/d95/classwx_s_f_text_shape.html#af6ec165c1dff0ac5fcd0b663a82d34ca',1,'wxSFTextShape']]],
  ['updateshape',['UpdateShape',['../d0/d60/classwx_s_f_control_shape.html#a382b7dcb62b6e7770bfec6c45c510a66',1,'wxSFControlShape']]],
  ['updatevirtualsize',['UpdateVirtualSize',['../db/d44/classwx_s_f_shape_canvas.html#a9f91313f4831225b6db0f23531ecd922',1,'wxSFShapeCanvas']]]
];
