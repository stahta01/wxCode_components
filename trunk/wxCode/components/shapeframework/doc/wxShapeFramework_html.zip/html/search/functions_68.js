var searchData=
[
  ['haschildren',['HasChildren',['../d2/d22/classwx_s_f_diagram_manager.html#aef127af757f65497c2443be586dd19af',1,'wxSFDiagramManager::HasChildren()'],['../de/d26/classxs_serializable.html#aa2a3e2a884aded3299d79773ecd6f883',1,'xsSerializable::HasChildren()']]],
  ['haspage',['HasPage',['../d8/d77/classwx_s_f_printout.html#a0d5125884edaf476ec1ebdaac817606f',1,'wxSFPrintout']]],
  ['hideallhandles',['HideAllHandles',['../db/d44/classwx_s_f_shape_canvas.html#ae0d9c0c947639e79731dac40cdfd109e',1,'wxSFShapeCanvas']]]
];
