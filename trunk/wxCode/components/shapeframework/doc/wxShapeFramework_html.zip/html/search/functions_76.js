var searchData=
[
  ['validateselection',['ValidateSelection',['../db/d44/classwx_s_f_shape_canvas.html#a952d252ee6978675ffbc091831de30c5',1,'wxSFShapeCanvas']]],
  ['validateselectionforclipboard',['ValidateSelectionForClipboard',['../db/d44/classwx_s_f_shape_canvas.html#a5caad7ff9ccc9648d13b71a893136fc7',1,'wxSFShapeCanvas']]],
  ['veto',['Veto',['../d6/d43/classwx_s_f_shape_event.html#a08a669ad329ac889b061f5f292d73548',1,'wxSFShapeEvent']]]
];
