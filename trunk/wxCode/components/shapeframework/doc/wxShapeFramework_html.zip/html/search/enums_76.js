var searchData=
[
  ['valign',['VALIGN',['../da/d88/classwx_s_f_shape_base.html#ada5980d3365334f22608ddcfe28b970e',1,'wxSFShapeBase::VALIGN()'],['../db/d44/classwx_s_f_shape_canvas.html#a0277dd3c0d00a9cb44431603a9683dcb',1,'wxSFShapeCanvas::VALIGN()']]]
];
