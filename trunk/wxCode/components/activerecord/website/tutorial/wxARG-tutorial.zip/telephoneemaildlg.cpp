/////////////////////////////////////////////////////////////////////////////
// Name:        telephoneemaildlg.cpp
// Purpose:     
// Author:      Mat�as Szeftel
// Modified by: 
// Created:     01/10/2006 01:22:20
// RCS-ID:      
// Copyright:   
// Licence:     
/////////////////////////////////////////////////////////////////////////////

#if defined(__GNUG__) && !defined(NO_GCC_PRAGMA)
#pragma implementation "telephoneemaildlg.h"
#endif

// For compilers that support precompilation, includes "wx/wx.h".
#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
#include "wx/wx.h"
#endif

////@begin includes
////@end includes

#include "telephoneemaildlg.h"

////@begin XPM images
////@end XPM images

/*!
 * TelephoneEmailDlg type definition
 */

IMPLEMENT_DYNAMIC_CLASS( TelephoneEmailDlg, wxDialog )

/*!
 * TelephoneEmailDlg event table definition
 */

BEGIN_EVENT_TABLE( TelephoneEmailDlg, wxDialog )

////@begin TelephoneEmailDlg event table entries
    EVT_UPDATE_UI( wxID_OK, TelephoneEmailDlg::OnOkUpdate )

////@end TelephoneEmailDlg event table entries

END_EVENT_TABLE()

/*!
 * TelephoneEmailDlg constructors
 */

TelephoneEmailDlg::TelephoneEmailDlg( )
{
}

TelephoneEmailDlg::TelephoneEmailDlg( wxWindow* parent, wxWindowID id, const wxString& caption, const wxPoint& pos, const wxSize& size, long style )
{
    Create(parent, id, caption, pos, size, style);
}

/*!
 * TelephoneEmailDlg creator
 */

bool TelephoneEmailDlg::Create( wxWindow* parent, wxWindowID id, const wxString& caption, const wxPoint& pos, const wxSize& size, long style )
{
////@begin TelephoneEmailDlg member initialisation
    st_value = NULL;
    tc_value = NULL;
    tc_description = NULL;
    btn_ok = NULL;
////@end TelephoneEmailDlg member initialisation

////@begin TelephoneEmailDlg creation
    SetExtraStyle(GetExtraStyle()|wxWS_EX_BLOCK_EVENTS);
    wxDialog::Create( parent, id, caption, pos, size, style );

    CreateControls();
    if (GetSizer())
    {
        GetSizer()->SetSizeHints(this);
    }
    Centre();
////@end TelephoneEmailDlg creation
    return true;
}

/*!
 * Control creation for TelephoneEmailDlg
 */

void TelephoneEmailDlg::CreateControls()
{    
////@begin TelephoneEmailDlg content construction
    TelephoneEmailDlg* itemDialog1 = this;

    wxBoxSizer* itemBoxSizer2 = new wxBoxSizer(wxVERTICAL);
    itemDialog1->SetSizer(itemBoxSizer2);

    wxBoxSizer* itemBoxSizer3 = new wxBoxSizer(wxHORIZONTAL);
    itemBoxSizer2->Add(itemBoxSizer3, 0, wxGROW|wxALL, 5);

    st_value = new wxStaticText( itemDialog1, wxID_STATIC, _("Number:"), wxDefaultPosition, wxDefaultSize, 0 );
    itemBoxSizer3->Add(st_value, 0, wxALIGN_CENTER_VERTICAL|wxALL|wxADJUST_MINSIZE, 5);

    tc_value = new wxTextCtrl( itemDialog1, ID_TEXTCTRL1, _T(""), wxDefaultPosition, wxSize(200, -1), 0 );
    itemBoxSizer3->Add(tc_value, 1, wxALIGN_CENTER_VERTICAL|wxALL, 5);

    wxStaticText* itemStaticText6 = new wxStaticText( itemDialog1, wxID_STATIC, _("Description:"), wxDefaultPosition, wxDefaultSize, 0 );
    itemBoxSizer3->Add(itemStaticText6, 0, wxALIGN_CENTER_VERTICAL|wxALL|wxADJUST_MINSIZE, 5);

    tc_description = new wxTextCtrl( itemDialog1, ID_TEXTCTRL2, _T(""), wxDefaultPosition, wxSize(200, -1), 0 );
    itemBoxSizer3->Add(tc_description, 1, wxALIGN_CENTER_VERTICAL|wxALL, 5);

    wxBoxSizer* itemBoxSizer8 = new wxBoxSizer(wxHORIZONTAL);
    itemBoxSizer2->Add(itemBoxSizer8, 0, wxALIGN_CENTER_HORIZONTAL|wxALL, 5);

    btn_ok = new wxButton( itemDialog1, wxID_OK, _("&OK"), wxDefaultPosition, wxDefaultSize, 0 );
    itemBoxSizer8->Add(btn_ok, 0, wxALIGN_CENTER_VERTICAL|wxALL, 5);

    wxButton* itemButton10 = new wxButton( itemDialog1, wxID_CANCEL, _("&Cancel"), wxDefaultPosition, wxDefaultSize, 0 );
    itemBoxSizer8->Add(itemButton10, 0, wxALIGN_CENTER_VERTICAL|wxALL, 5);

////@end TelephoneEmailDlg content construction
}

/*!
 * Should we show tooltips?
 */

bool TelephoneEmailDlg::ShowToolTips()
{
    return true;
}

/*!
 * Get bitmap resources
 */

wxBitmap TelephoneEmailDlg::GetBitmapResource( const wxString& name )
{
    // Bitmap retrieval
////@begin TelephoneEmailDlg bitmap retrieval
    wxUnusedVar(name);
    return wxNullBitmap;
////@end TelephoneEmailDlg bitmap retrieval
}

/*!
 * Get icon resources
 */

wxIcon TelephoneEmailDlg::GetIconResource( const wxString& name )
{
    // Icon retrieval
////@begin TelephoneEmailDlg icon retrieval
    wxUnusedVar(name);
    return wxNullIcon;
////@end TelephoneEmailDlg icon retrieval
}
/*!
 * wxEVT_UPDATE_UI event handler for wxID_OK
 */

void TelephoneEmailDlg::OnOkUpdate( wxUpdateUIEvent& event )
{
	if(tc_value->GetValue().IsEmpty())
		btn_ok->Enable(false);
	else
		btn_ok->Enable(true);
}


