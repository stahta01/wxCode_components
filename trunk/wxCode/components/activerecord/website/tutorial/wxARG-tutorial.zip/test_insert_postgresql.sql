INSERT INTO contacts("lastName","firstName",address) VALUES('Szeftel','Mat�as','Somewhere in Argentina');
INSERT INTO contacts("lastName","firstName",address) VALUES('Gates','Bill','Somewhere in Hell');
INSERT INTO contacts("lastName","firstName",address) VALUES('My Best','Friend','Somewhere in Argentina');
INSERT INTO contacts("lastName","firstName",address) VALUES('My Pet Fish','Aurelius','My house');
INSERT INTO contacts("lastName","firstName",address) VALUES('Someone','You know','Somewhere in the world');
INSERT INTO contacts("lastName","firstName",address) VALUES('Asd','No first name','Paris');

INSERT INTO telephones(contact_id,priority,number,description) VALUES(1,1,'1245-4657-7777','House');
INSERT INTO telephones(contact_id,priority,number,description) VALUES(1,2,'1435-4657-4444','Work');
INSERT INTO telephones(contact_id,priority,number,description) VALUES(1,3,'1045-4657-7777','Room');
INSERT INTO telephones(contact_id,priority,number,description) VALUES(2,1,'666','House');
INSERT INTO telephones(contact_id,priority,number,description) VALUES(2,2,'666','Work');

INSERT INTO emails(contact_id,priority,email,description) VALUES(1,1,'mszeftel@yahoo.com.ar','Personal');
INSERT INTO emails(contact_id,priority,email,description) VALUES(1,2,'asd@asd.org','Email 2');
INSERT INTO emails(contact_id,priority,email,description) VALUES(1,3,'wxarg@nodomainatall.org','Alternate');
INSERT INTO emails(contact_id,priority,email,description) VALUES(2,1,'gimeurmoney@microsoft.com.hl','At hell');
INSERT INTO emails(contact_id,priority,email,description) VALUES(2,2,'bluescreen@ofdeath.com','Complains');