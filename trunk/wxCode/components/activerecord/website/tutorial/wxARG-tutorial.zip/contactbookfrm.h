/////////////////////////////////////////////////////////////////////////////
// Name:        contactbookfrm.h
// Purpose:     
// Author:      Mat�as Szeftel
// Modified by: 
// Created:     30/09/2006 00:55:02
// RCS-ID:      
// Copyright:   
// Licence:     
/////////////////////////////////////////////////////////////////////////////

#ifndef _CONTACTBOOKFRM_H_
#define _CONTACTBOOKFRM_H_

#if defined(__GNUG__) && !defined(NO_GCC_PRAGMA)
#pragma interface "contactbookfrm.h"
#endif

/*!
 * Includes
 */

////@begin includes
#include "wx/frame.h"
#include "wx/splitter.h"
#include "wx/listctrl.h"
#include "wx/notebook.h"
////@end includes
#include "vld.h"
#include "SQLite/Contact.h"
#include "SQLite/Email.h"
#include "SQLite/Telephone.h"
#include "telephoneemaildlg.h"
/*!
 * Forward declarations
 */

////@begin forward declarations
class wxListView;
////@end forward declarations

/*!
 * Control identifiers
 */

////@begin control identifiers
#define ID_FRAME 10000
#define SYMBOL_CONTACTBOOKFRM_STYLE wxCAPTION|wxRESIZE_BORDER|wxSYSTEM_MENU|wxMINIMIZE_BOX|wxMAXIMIZE_BOX|wxCLOSE_BOX
#define SYMBOL_CONTACTBOOKFRM_TITLE _("Contact Book")
#define SYMBOL_CONTACTBOOKFRM_IDNAME ID_FRAME
#define SYMBOL_CONTACTBOOKFRM_SIZE wxSize(800, 600)
#define SYMBOL_CONTACTBOOKFRM_POSITION wxDefaultPosition
#define ID_PANEL1 10001
#define ID_SPLITTERWINDOW1 10002
#define ID_CONTACTSPANEL 10003
#define ID_LVCONTACTS 10005
#define ID_BTNNEW 10006
#define ID_BTNDELETE 10025
#define ID_PROPERTIESPANEL 10004
#define ID_NOTEBOOK1 10008
#define ID_PANEL2 10011
#define ID_TCLASTNAME 10012
#define ID_TCFIRSTNAME 10013
#define ID_TCADDRESS 10014
#define ID_LVTELEPHONES 10015
#define ID_NEWTEL 10016
#define ID_EDITTEL 10017
#define ID_DELETETEL 10018
#define ID_LVEMAILS 10019
#define ID_NEWEMAIL 10020
#define ID_EDITEMAIL 10021
#define ID_DELETEEMAIL 10022
#define ID_APPLY 10009
#define ID_CANCEL 10010
////@end control identifiers

/*!
 * Compatibility
 */

#ifndef wxCLOSE_BOX
#define wxCLOSE_BOX 0x1000
#endif

/*!
 * ContactBookFrm class declaration
 */

class ContactBookFrm: public wxFrame
{    
    DECLARE_CLASS( ContactBookFrm )
    DECLARE_EVENT_TABLE()

public:
    /// Constructors
    ContactBookFrm( );
    ContactBookFrm( wxWindow* parent, wxWindowID id = SYMBOL_CONTACTBOOKFRM_IDNAME, const wxString& caption = SYMBOL_CONTACTBOOKFRM_TITLE, const wxPoint& pos = SYMBOL_CONTACTBOOKFRM_POSITION, const wxSize& size = SYMBOL_CONTACTBOOKFRM_SIZE, long style = SYMBOL_CONTACTBOOKFRM_STYLE );

    bool Create( wxWindow* parent, wxWindowID id = SYMBOL_CONTACTBOOKFRM_IDNAME, const wxString& caption = SYMBOL_CONTACTBOOKFRM_TITLE, const wxPoint& pos = SYMBOL_CONTACTBOOKFRM_POSITION, const wxSize& size = SYMBOL_CONTACTBOOKFRM_SIZE, long style = SYMBOL_CONTACTBOOKFRM_STYLE );

    /// Creates the controls and sizers
    void CreateControls();

////@begin ContactBookFrm event handler declarations

    /// wxEVT_CLOSE_WINDOW event handler for ID_FRAME
    void OnCloseWindow( wxCloseEvent& event );

    /// wxEVT_COMMAND_LIST_ITEM_SELECTED event handler for ID_LVCONTACTS
    void OnLvcontactsSelected( wxListEvent& event );

    /// wxEVT_COMMAND_BUTTON_CLICKED event handler for ID_BTNNEW
    void OnBtnnewClick( wxCommandEvent& event );

    /// wxEVT_COMMAND_BUTTON_CLICKED event handler for ID_BTNDELETE
    void OnBtndeleteClick( wxCommandEvent& event );

    /// wxEVT_UPDATE_UI event handler for ID_BTNDELETE
    void OnBtndeleteUpdate( wxUpdateUIEvent& event );

    /// wxEVT_COMMAND_LIST_ITEM_ACTIVATED event handler for ID_LVTELEPHONES
    void OnLvtelephonesItemActivated( wxListEvent& event );

    /// wxEVT_COMMAND_BUTTON_CLICKED event handler for ID_NEWTEL
    void OnNewtelClick( wxCommandEvent& event );

    /// wxEVT_COMMAND_BUTTON_CLICKED event handler for ID_EDITTEL
    void OnEdittelClick( wxCommandEvent& event );

    /// wxEVT_UPDATE_UI event handler for ID_EDITTEL
    void OnEdittelUpdate( wxUpdateUIEvent& event );

    /// wxEVT_COMMAND_BUTTON_CLICKED event handler for ID_DELETETEL
    void OnDeletetelClick( wxCommandEvent& event );

    /// wxEVT_UPDATE_UI event handler for ID_DELETETEL
    void OnDeletetelUpdate( wxUpdateUIEvent& event );

    /// wxEVT_COMMAND_LIST_ITEM_ACTIVATED event handler for ID_LVEMAILS
    void OnLvemailsItemActivated( wxListEvent& event );

    /// wxEVT_COMMAND_BUTTON_CLICKED event handler for ID_NEWEMAIL
    void OnNewemailClick( wxCommandEvent& event );

    /// wxEVT_COMMAND_BUTTON_CLICKED event handler for ID_EDITEMAIL
    void OnEditemailClick( wxCommandEvent& event );

    /// wxEVT_UPDATE_UI event handler for ID_EDITEMAIL
    void OnEditemailUpdate( wxUpdateUIEvent& event );

    /// wxEVT_COMMAND_BUTTON_CLICKED event handler for ID_DELETEEMAIL
    void OnDeleteemailClick( wxCommandEvent& event );

    /// wxEVT_UPDATE_UI event handler for ID_DELETEEMAIL
    void OnDeleteemailUpdate( wxUpdateUIEvent& event );

    /// wxEVT_COMMAND_BUTTON_CLICKED event handler for ID_APPLY
    void OnApplyClick( wxCommandEvent& event );

    /// wxEVT_UPDATE_UI event handler for ID_APPLY
    void OnApplyUpdate( wxUpdateUIEvent& event );

    /// wxEVT_COMMAND_BUTTON_CLICKED event handler for ID_CANCEL
    void OnCancelClick( wxCommandEvent& event );

    /// wxEVT_UPDATE_UI event handler for ID_CANCEL
    void OnCancelUpdate( wxUpdateUIEvent& event );

////@end ContactBookFrm event handler declarations

////@begin ContactBookFrm member function declarations

    /// Retrieves bitmap resources
    wxBitmap GetBitmapResource( const wxString& name );

    /// Retrieves icon resources
    wxIcon GetIconResource( const wxString& name );
////@end ContactBookFrm member function declarations

    /// Should we show tooltips?
    static bool ShowToolTips();

////@begin ContactBookFrm member variables
    wxPanel* contactsPanel;
    wxListView* lv_contacts;
    wxButton* btn_new;
    wxButton* btn_delete;
    wxPanel* panelProperties;
    wxPanel* propertiesTab;
    wxTextCtrl* tc_lastName;
    wxTextCtrl* tc_firstName;
    wxTextCtrl* tc_address;
    wxListView* lv_telephones;
    wxButton* btn_newTel;
    wxButton* btn_editTel;
    wxButton* btn_deleteTel;
    wxListView* lv_emails;
    wxButton* btn_newEmail;
    wxButton* btn_editEmail;
    wxButton* btn_deleteEmail;
    wxButton* btn_apply;
    wxButton* btn_cancel;
////@end ContactBookFrm member variables
	Contact* contact;
	Telephone* telephone;
	Email* email;
	void Load(ContactRow* row);
	void LoadContactList();
		
	ContactRow* loaded;
	TelephoneRowSet* loadedTels;
	EmailRowSet* loadedEmails;
};

#endif
    // _CONTACTBOOKFRM_H_
