CREATE TABLE contacts(id INTEGER PRIMARY KEY, firstName TEXT, lastName TEXT, address TEXT);
CREATE TABLE telephones(id INTEGER PRIMARY KEY, contact_id INTEGER NOT NULL, priority INTEGER NOT NULL, number TEXT NOT NULL, description TEXT);
CREATE TABLE emails(id INTEGER PRIMARY KEY, contact_id INTEGER NOT NULL, priority INTEGER NOT NULL, email TEXT NOT NULL, description TEXT);
