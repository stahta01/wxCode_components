/////////////////////////////////////////////////////////////////////////////
// Name:        telephoneemaildlg.h
// Purpose:     
// Author:      Mat�as Szeftel
// Modified by: 
// Created:     01/10/2006 01:22:20
// RCS-ID:      
// Copyright:   
// Licence:     
/////////////////////////////////////////////////////////////////////////////

#ifndef _TELEPHONEEMAILDLG_H_
#define _TELEPHONEEMAILDLG_H_

#if defined(__GNUG__) && !defined(NO_GCC_PRAGMA)
#pragma interface "telephoneemaildlg.h"
#endif

/*!
 * Includes
 */

////@begin includes
////@end includes

/*!
 * Forward declarations
 */

////@begin forward declarations
////@end forward declarations

/*!
 * Control identifiers
 */

////@begin control identifiers
#define ID_DIALOG 10007
#define SYMBOL_TELEPHONEEMAILDLG_STYLE wxCAPTION|wxRESIZE_BORDER|wxSYSTEM_MENU|wxCLOSE_BOX
#define SYMBOL_TELEPHONEEMAILDLG_TITLE _("Dialog")
#define SYMBOL_TELEPHONEEMAILDLG_IDNAME ID_DIALOG
#define SYMBOL_TELEPHONEEMAILDLG_SIZE wxSize(400, 300)
#define SYMBOL_TELEPHONEEMAILDLG_POSITION wxDefaultPosition
#define ID_TEXTCTRL1 10023
#define ID_TEXTCTRL2 10024
////@end control identifiers

/*!
 * Compatibility
 */

#ifndef wxCLOSE_BOX
#define wxCLOSE_BOX 0x1000
#endif

/*!
 * TelephoneEmailDlg class declaration
 */

class TelephoneEmailDlg: public wxDialog
{    
    DECLARE_DYNAMIC_CLASS( TelephoneEmailDlg )
    DECLARE_EVENT_TABLE()

public:
    /// Constructors
    TelephoneEmailDlg( );
    TelephoneEmailDlg( wxWindow* parent, wxWindowID id = SYMBOL_TELEPHONEEMAILDLG_IDNAME, const wxString& caption = SYMBOL_TELEPHONEEMAILDLG_TITLE, const wxPoint& pos = SYMBOL_TELEPHONEEMAILDLG_POSITION, const wxSize& size = SYMBOL_TELEPHONEEMAILDLG_SIZE, long style = SYMBOL_TELEPHONEEMAILDLG_STYLE );

    /// Creation
    bool Create( wxWindow* parent, wxWindowID id = SYMBOL_TELEPHONEEMAILDLG_IDNAME, const wxString& caption = SYMBOL_TELEPHONEEMAILDLG_TITLE, const wxPoint& pos = SYMBOL_TELEPHONEEMAILDLG_POSITION, const wxSize& size = SYMBOL_TELEPHONEEMAILDLG_SIZE, long style = SYMBOL_TELEPHONEEMAILDLG_STYLE );

    /// Creates the controls and sizers
    void CreateControls();

////@begin TelephoneEmailDlg event handler declarations

    /// wxEVT_UPDATE_UI event handler for wxID_OK
    void OnOkUpdate( wxUpdateUIEvent& event );

////@end TelephoneEmailDlg event handler declarations

////@begin TelephoneEmailDlg member function declarations

    /// Retrieves bitmap resources
    wxBitmap GetBitmapResource( const wxString& name );

    /// Retrieves icon resources
    wxIcon GetIconResource( const wxString& name );
////@end TelephoneEmailDlg member function declarations

    /// Should we show tooltips?
    static bool ShowToolTips();

////@begin TelephoneEmailDlg member variables
    wxStaticText* st_value;
    wxTextCtrl* tc_value;
    wxTextCtrl* tc_description;
    wxButton* btn_ok;
////@end TelephoneEmailDlg member variables
};

#endif
    // _TELEPHONEEMAILDLG_H_
