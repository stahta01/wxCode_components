/////////////////////////////////////////////////////////////////////////////
// Name:        tutorial_wxargapp.h
// Purpose:     
// Author:      Mat�as Szeftel
// Modified by: 
// Created:     30/09/2006 00:53:20
// RCS-ID:      
// Copyright:   
// Licence:     
/////////////////////////////////////////////////////////////////////////////

#ifndef _TUTORIAL_WXARGAPP_H_
#define _TUTORIAL_WXARGAPP_H_

#if defined(__GNUG__) && !defined(NO_GCC_PRAGMA)
#pragma interface "tutorial_wxargapp.h"
#endif

/*!
 * Includes
 */

////@begin includes
#include "wx/image.h"
#include "contactbookfrm.h"
////@end includes

/*!
 * Forward declarations
 */

////@begin forward declarations
////@end forward declarations

/*!
 * Control identifiers
 */

////@begin control identifiers
////@end control identifiers

/*!
 * Tutorial_wxARGApp class declaration
 */

class Tutorial_wxARGApp: public wxApp
{    
    DECLARE_CLASS( Tutorial_wxARGApp )
    DECLARE_EVENT_TABLE()

public:
    /// Constructor
    Tutorial_wxARGApp();

    /// Initialises the application
    virtual bool OnInit();

    /// Called on exit
    virtual int OnExit();

////@begin Tutorial_wxARGApp event handler declarations

////@end Tutorial_wxARGApp event handler declarations

////@begin Tutorial_wxARGApp member function declarations

////@end Tutorial_wxARGApp member function declarations

////@begin Tutorial_wxARGApp member variables
////@end Tutorial_wxARGApp member variables
};

/*!
 * Application instance declaration 
 */

////@begin declare app
DECLARE_APP(Tutorial_wxARGApp)
////@end declare app

#endif
    // _TUTORIAL_WXARGAPP_H_
