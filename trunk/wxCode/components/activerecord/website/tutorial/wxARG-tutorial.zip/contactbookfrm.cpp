/////////////////////////////////////////////////////////////////////////////
// Name:        contactbookfrm.cpp
// Purpose:     
// Author:      Mat�as Szeftel
// Modified by: 
// Created:     30/09/2006 00:55:02
// RCS-ID:      
// Copyright:   
// Licence:     
/////////////////////////////////////////////////////////////////////////////

#if defined(__GNUG__) && !defined(NO_GCC_PRAGMA)
#pragma implementation "contactbookfrm.h"
#endif

// For compilers that support precompilation, includes "wx/wx.h".
#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
#include "wx/wx.h"
#endif

////@begin includes
////@end includes

#include "contactbookfrm.h"

////@begin XPM images
////@end XPM images

/*!
 * ContactBookFrm type definition
 */

IMPLEMENT_CLASS( ContactBookFrm, wxFrame )

/*!
 * ContactBookFrm event table definition
 */

BEGIN_EVENT_TABLE( ContactBookFrm, wxFrame )

////@begin ContactBookFrm event table entries
    EVT_CLOSE( ContactBookFrm::OnCloseWindow )

    EVT_LIST_ITEM_SELECTED( ID_LVCONTACTS, ContactBookFrm::OnLvcontactsSelected )

    EVT_BUTTON( ID_BTNNEW, ContactBookFrm::OnBtnnewClick )

    EVT_BUTTON( ID_BTNDELETE, ContactBookFrm::OnBtndeleteClick )
    EVT_UPDATE_UI( ID_BTNDELETE, ContactBookFrm::OnBtndeleteUpdate )

    EVT_LIST_ITEM_ACTIVATED( ID_LVTELEPHONES, ContactBookFrm::OnLvtelephonesItemActivated )

    EVT_BUTTON( ID_NEWTEL, ContactBookFrm::OnNewtelClick )

    EVT_BUTTON( ID_EDITTEL, ContactBookFrm::OnEdittelClick )
    EVT_UPDATE_UI( ID_EDITTEL, ContactBookFrm::OnEdittelUpdate )

    EVT_BUTTON( ID_DELETETEL, ContactBookFrm::OnDeletetelClick )
    EVT_UPDATE_UI( ID_DELETETEL, ContactBookFrm::OnDeletetelUpdate )

    EVT_LIST_ITEM_ACTIVATED( ID_LVEMAILS, ContactBookFrm::OnLvemailsItemActivated )

    EVT_BUTTON( ID_NEWEMAIL, ContactBookFrm::OnNewemailClick )

    EVT_BUTTON( ID_EDITEMAIL, ContactBookFrm::OnEditemailClick )
    EVT_UPDATE_UI( ID_EDITEMAIL, ContactBookFrm::OnEditemailUpdate )

    EVT_BUTTON( ID_DELETEEMAIL, ContactBookFrm::OnDeleteemailClick )
    EVT_UPDATE_UI( ID_DELETEEMAIL, ContactBookFrm::OnDeleteemailUpdate )

    EVT_BUTTON( ID_APPLY, ContactBookFrm::OnApplyClick )
    EVT_UPDATE_UI( ID_APPLY, ContactBookFrm::OnApplyUpdate )

    EVT_BUTTON( ID_CANCEL, ContactBookFrm::OnCancelClick )
    EVT_UPDATE_UI( ID_CANCEL, ContactBookFrm::OnCancelUpdate )

////@end ContactBookFrm event table entries

END_EVENT_TABLE()

/*!
 * ContactBookFrm constructors
 */

ContactBookFrm::ContactBookFrm( )
{
}

ContactBookFrm::ContactBookFrm( wxWindow* parent, wxWindowID id, const wxString& caption, const wxPoint& pos, const wxSize& size, long style )
{
    Create( parent, id, caption, pos, size, style );
}

/*!
 * ContactBookFrm creator
 */

bool ContactBookFrm::Create( wxWindow* parent, wxWindowID id, const wxString& caption, const wxPoint& pos, const wxSize& size, long style )
{
////@begin ContactBookFrm member initialisation
    contactsPanel = NULL;
    lv_contacts = NULL;
    btn_new = NULL;
    btn_delete = NULL;
    panelProperties = NULL;
    propertiesTab = NULL;
    tc_lastName = NULL;
    tc_firstName = NULL;
    tc_address = NULL;
    lv_telephones = NULL;
    btn_newTel = NULL;
    btn_editTel = NULL;
    btn_deleteTel = NULL;
    lv_emails = NULL;
    btn_newEmail = NULL;
    btn_editEmail = NULL;
    btn_deleteEmail = NULL;
    btn_apply = NULL;
    btn_cancel = NULL;
////@end ContactBookFrm member initialisation

////@begin ContactBookFrm creation
    wxFrame::Create( parent, id, caption, pos, size, style );

    CreateControls();
    Centre();
////@end ContactBookFrm creation
    return true;
}

/*!
 * Control creation for ContactBookFrm
 */

void ContactBookFrm::CreateControls()
{    
////@begin ContactBookFrm content construction
    ContactBookFrm* itemFrame1 = this;

    wxBoxSizer* itemBoxSizer2 = new wxBoxSizer(wxHORIZONTAL);
    itemFrame1->SetSizer(itemBoxSizer2);

    wxPanel* itemPanel3 = new wxPanel( itemFrame1, ID_PANEL1, wxDefaultPosition, wxDefaultSize, wxSUNKEN_BORDER|wxTAB_TRAVERSAL );
    itemBoxSizer2->Add(itemPanel3, 1, wxGROW|wxALL, 0);

    wxBoxSizer* itemBoxSizer4 = new wxBoxSizer(wxHORIZONTAL);
    itemPanel3->SetSizer(itemBoxSizer4);

    wxSplitterWindow* itemSplitterWindow5 = new wxSplitterWindow( itemPanel3, ID_SPLITTERWINDOW1, wxDefaultPosition, wxSize(100, 100), wxSP_3DBORDER|wxSP_3DSASH|wxNO_BORDER );
    itemSplitterWindow5->SetMinimumPaneSize(0);

    contactsPanel = new wxPanel( itemSplitterWindow5, ID_CONTACTSPANEL, wxDefaultPosition, wxDefaultSize, wxSUNKEN_BORDER|wxTAB_TRAVERSAL );
    wxBoxSizer* itemBoxSizer7 = new wxBoxSizer(wxVERTICAL);
    contactsPanel->SetSizer(itemBoxSizer7);

    lv_contacts = new wxListView( contactsPanel, ID_LVCONTACTS, wxDefaultPosition, wxSize(100, 100), wxLC_REPORT|wxLC_SINGLE_SEL );
    itemBoxSizer7->Add(lv_contacts, 1, wxGROW|wxALL, 5);

    wxBoxSizer* itemBoxSizer9 = new wxBoxSizer(wxHORIZONTAL);
    itemBoxSizer7->Add(itemBoxSizer9, 0, wxALIGN_CENTER_HORIZONTAL|wxALL, 5);
    btn_new = new wxButton( contactsPanel, ID_BTNNEW, _("New"), wxDefaultPosition, wxDefaultSize, 0 );
    itemBoxSizer9->Add(btn_new, 0, wxALIGN_CENTER_VERTICAL|wxALL, 5);

    btn_delete = new wxButton( contactsPanel, ID_BTNDELETE, _("Delete"), wxDefaultPosition, wxDefaultSize, 0 );
    itemBoxSizer9->Add(btn_delete, 0, wxALIGN_CENTER_VERTICAL|wxALL, 5);

    panelProperties = new wxPanel( itemSplitterWindow5, ID_PROPERTIESPANEL, wxDefaultPosition, wxDefaultSize, wxSUNKEN_BORDER|wxTAB_TRAVERSAL );
    wxBoxSizer* itemBoxSizer13 = new wxBoxSizer(wxVERTICAL);
    panelProperties->SetSizer(itemBoxSizer13);

    wxNotebook* itemNotebook14 = new wxNotebook( panelProperties, ID_NOTEBOOK1, wxDefaultPosition, wxDefaultSize, wxNB_TOP );

    propertiesTab = new wxPanel( itemNotebook14, ID_PANEL2, wxDefaultPosition, wxDefaultSize, wxSUNKEN_BORDER|wxTAB_TRAVERSAL );
    wxBoxSizer* itemBoxSizer16 = new wxBoxSizer(wxVERTICAL);
    propertiesTab->SetSizer(itemBoxSizer16);

    wxBoxSizer* itemBoxSizer17 = new wxBoxSizer(wxHORIZONTAL);
    itemBoxSizer16->Add(itemBoxSizer17, 0, wxGROW|wxALL, 5);
    wxStaticText* itemStaticText18 = new wxStaticText( propertiesTab, wxID_STATIC, _("Last Name:"), wxDefaultPosition, wxDefaultSize, 0 );
    itemBoxSizer17->Add(itemStaticText18, 0, wxALIGN_CENTER_VERTICAL|wxALL|wxADJUST_MINSIZE, 5);

    tc_lastName = new wxTextCtrl( propertiesTab, ID_TCLASTNAME, _T(""), wxDefaultPosition, wxDefaultSize, 0 );
    itemBoxSizer17->Add(tc_lastName, 1, wxALIGN_CENTER_VERTICAL|wxALL, 5);

    wxStaticText* itemStaticText20 = new wxStaticText( propertiesTab, wxID_STATIC, _("First Name:"), wxDefaultPosition, wxDefaultSize, 0 );
    itemBoxSizer17->Add(itemStaticText20, 0, wxALIGN_CENTER_VERTICAL|wxALL|wxADJUST_MINSIZE, 5);

    tc_firstName = new wxTextCtrl( propertiesTab, ID_TCFIRSTNAME, _T(""), wxDefaultPosition, wxDefaultSize, 0 );
    itemBoxSizer17->Add(tc_firstName, 1, wxALIGN_CENTER_VERTICAL|wxALL, 5);

    wxBoxSizer* itemBoxSizer22 = new wxBoxSizer(wxHORIZONTAL);
    itemBoxSizer16->Add(itemBoxSizer22, 0, wxGROW|wxALL, 5);
    wxStaticText* itemStaticText23 = new wxStaticText( propertiesTab, wxID_STATIC, _("Address:"), wxDefaultPosition, wxDefaultSize, 0 );
    itemBoxSizer22->Add(itemStaticText23, 0, wxALIGN_CENTER_VERTICAL|wxALL|wxADJUST_MINSIZE, 5);

    tc_address = new wxTextCtrl( propertiesTab, ID_TCADDRESS, _T(""), wxDefaultPosition, wxDefaultSize, 0 );
    itemBoxSizer22->Add(tc_address, 1, wxALIGN_CENTER_VERTICAL|wxALL, 5);

    wxStaticBox* itemStaticBoxSizer25Static = new wxStaticBox(propertiesTab, wxID_ANY, _("Telephones:"));
    wxStaticBoxSizer* itemStaticBoxSizer25 = new wxStaticBoxSizer(itemStaticBoxSizer25Static, wxHORIZONTAL);
    itemBoxSizer16->Add(itemStaticBoxSizer25, 1, wxGROW|wxALL, 5);
    lv_telephones = new wxListView( propertiesTab, ID_LVTELEPHONES, wxDefaultPosition, wxSize(100, 100), wxLC_REPORT|wxLC_SINGLE_SEL );
    itemStaticBoxSizer25->Add(lv_telephones, 1, wxGROW|wxALL, 5);

    wxBoxSizer* itemBoxSizer27 = new wxBoxSizer(wxVERTICAL);
    itemStaticBoxSizer25->Add(itemBoxSizer27, 0, wxALIGN_TOP|wxALL, 5);
    btn_newTel = new wxButton( propertiesTab, ID_NEWTEL, _("New"), wxDefaultPosition, wxDefaultSize, 0 );
    itemBoxSizer27->Add(btn_newTel, 0, wxALIGN_CENTER_HORIZONTAL|wxALL, 5);

    btn_editTel = new wxButton( propertiesTab, ID_EDITTEL, _("Edit"), wxDefaultPosition, wxDefaultSize, 0 );
    itemBoxSizer27->Add(btn_editTel, 0, wxALIGN_CENTER_HORIZONTAL|wxALL, 5);

    btn_deleteTel = new wxButton( propertiesTab, ID_DELETETEL, _("Delete"), wxDefaultPosition, wxDefaultSize, 0 );
    itemBoxSizer27->Add(btn_deleteTel, 0, wxALIGN_CENTER_HORIZONTAL|wxALL, 5);

    wxStaticBox* itemStaticBoxSizer31Static = new wxStaticBox(propertiesTab, wxID_ANY, _("Emails:"));
    wxStaticBoxSizer* itemStaticBoxSizer31 = new wxStaticBoxSizer(itemStaticBoxSizer31Static, wxHORIZONTAL);
    itemBoxSizer16->Add(itemStaticBoxSizer31, 1, wxGROW|wxALL, 5);
    lv_emails = new wxListView( propertiesTab, ID_LVEMAILS, wxDefaultPosition, wxSize(100, 100), wxLC_REPORT|wxLC_SINGLE_SEL );
    itemStaticBoxSizer31->Add(lv_emails, 1, wxGROW|wxALL, 5);

    wxBoxSizer* itemBoxSizer33 = new wxBoxSizer(wxVERTICAL);
    itemStaticBoxSizer31->Add(itemBoxSizer33, 0, wxALIGN_TOP|wxALL, 5);
    btn_newEmail = new wxButton( propertiesTab, ID_NEWEMAIL, _("New"), wxDefaultPosition, wxDefaultSize, 0 );
    itemBoxSizer33->Add(btn_newEmail, 0, wxALIGN_CENTER_HORIZONTAL|wxALL, 5);

    btn_editEmail = new wxButton( propertiesTab, ID_EDITEMAIL, _("Edit"), wxDefaultPosition, wxDefaultSize, 0 );
    itemBoxSizer33->Add(btn_editEmail, 0, wxALIGN_CENTER_HORIZONTAL|wxALL, 5);

    btn_deleteEmail = new wxButton( propertiesTab, ID_DELETEEMAIL, _("Delete"), wxDefaultPosition, wxDefaultSize, 0 );
    itemBoxSizer33->Add(btn_deleteEmail, 0, wxALIGN_CENTER_HORIZONTAL|wxALL, 5);

    itemNotebook14->AddPage(propertiesTab, _("Properties"));

    itemBoxSizer13->Add(itemNotebook14, 1, wxGROW|wxALL, 5);

    wxBoxSizer* itemBoxSizer37 = new wxBoxSizer(wxHORIZONTAL);
    itemBoxSizer13->Add(itemBoxSizer37, 0, wxALIGN_RIGHT|wxALL, 5);
    btn_apply = new wxButton( panelProperties, ID_APPLY, _("Apply"), wxDefaultPosition, wxDefaultSize, 0 );
    itemBoxSizer37->Add(btn_apply, 0, wxALIGN_CENTER_VERTICAL|wxALL, 5);

    btn_cancel = new wxButton( panelProperties, ID_CANCEL, _("Cancel"), wxDefaultPosition, wxDefaultSize, 0 );
    itemBoxSizer37->Add(btn_cancel, 0, wxALIGN_CENTER_VERTICAL|wxALL, 5);

    itemSplitterWindow5->SplitVertically(contactsPanel, panelProperties, 200);
    itemBoxSizer4->Add(itemSplitterWindow5, 1, wxGROW|wxALL, 5);

////@end ContactBookFrm content construction
	
	//Contacts ListView inicialization
	lv_contacts->InsertColumn(0,wxT("Last Name"));
	lv_contacts->InsertColumn(1,wxT("First Name"));
	lv_contacts->SetColumnWidth(0,90);
	lv_contacts->SetColumnWidth(1,90);
	
	//Telephones ListView inicialization
	lv_telephones->InsertColumn(0,wxT("Number"),wxLIST_FORMAT_RIGHT);
	lv_telephones->InsertColumn(1,wxT("Description"));
	lv_telephones->SetColumnWidth(0,200);
	lv_telephones->SetColumnWidth(1,200);

	//Emails ListView incialization
	lv_emails->InsertColumn(0,wxT("Email"));
	lv_emails->InsertColumn(1,wxT("Description"));
	lv_emails->SetColumnWidth(0,200);
	lv_emails->SetColumnWidth(1,200);
	
	try{
		//Active Records inicialization
		contact=new Contact(wxT("contacts"),wxT("contact_book.db3"));
		telephone=new Telephone(contact->GetDatabase(),wxT("telephones"));
		email=new Email(contact->GetDatabase(),wxT("emails"));
	}
	catch(DatabaseLayerException& e){
		wxActiveRecord::ProcessException(e);
		Close();
	}

	loaded=NULL;
	
	//Load the contact list
	LoadContactList();

}

/*!
 * Should we show tooltips?
 */

bool ContactBookFrm::ShowToolTips()
{
    return true;
}

/*!
 * Get bitmap resources
 */

wxBitmap ContactBookFrm::GetBitmapResource( const wxString& name )
{
    // Bitmap retrieval
////@begin ContactBookFrm bitmap retrieval
    wxUnusedVar(name);
    return wxNullBitmap;
////@end ContactBookFrm bitmap retrieval
}

/*!
 * Get icon resources
 */

wxIcon ContactBookFrm::GetIconResource( const wxString& name )
{
    // Icon retrieval
////@begin ContactBookFrm icon retrieval
    wxUnusedVar(name);
    return wxNullIcon;
////@end ContactBookFrm icon retrieval
}
/*!
 * wxEVT_COMMAND_BUTTON_CLICKED event handler for ID_BTNNEW
 */

void ContactBookFrm::OnBtnnewClick( wxCommandEvent& event )
{
    ContactRow* newRow=contact->New(); //get a new ContactRow*
    Load(newRow); //Load it
    tc_lastName->SetFocus();
}


/*!
 * wxEVT_COMMAND_BUTTON_CLICKED event handler for ID_BTNDELETE
 */

void ContactBookFrm::OnBtndeleteClick( wxCommandEvent& event )
{   
    //Ask: you sure u want to delete?
    wxMessageDialog dlg(this,wxT("Are you sure you want to delete this contact?"),wxT("Warning"),wxYES_NO);
    if(dlg.ShowModal()==wxID_NO)
        return; //if answer NO do nothing.
    try{
        long index=lv_contacts->GetFirstSelected();//get the index the selected contact

        contact->Delete(lv_contacts->GetItemData(index)); //use the active record to the delete the contact using the id returned by GetItemData()
        lv_contacts->DeleteItem(index); //delete from the ListView
    }
    catch(DatabaseLayerException& e){
        wxActiveRecord::ProcessException(e);
    }
   
}


/*!
 * wxEVT_UPDATE_UI event handler for ID_BTNDELETE
 */

void ContactBookFrm::OnBtndeleteUpdate( wxUpdateUIEvent& event )
{
	if(lv_contacts->GetFirstSelected()<0)
		btn_delete->Enable(false);
	else
		btn_delete->Enable(true);
}


/*!
 * wxEVT_COMMAND_BUTTON_CLICKED event handler for ID_NEWTEL
 */


void ContactBookFrm::OnNewtelClick( wxCommandEvent& event )
{
    TelephoneEmailDlg dlg(this,wxID_ANY,wxT("New Telephone")); //cretethe dialog
    dlg.st_value->SetLabel(wxT("Number:")); //show it
    if(dlg.ShowModal()==wxID_OK){ //if OK
        TelephoneRow* newTel=telephone->New(); //create a new phone
        newTel->contact_id=loaded->id; //assign it the id
        newTel->priority=loadedTels->Count()+1; //set the priority
        newTel->number=dlg.tc_value->GetValue(); //set the number
        newTel->description=dlg.tc_description->GetValue(); //set the description

        newTel->Save(); //save it

        Load(loaded); //load this contact again to reflect changes
    }
}


/*!
 * wxEVT_COMMAND_BUTTON_CLICKED event handler for ID_EDITTEL
 */

void ContactBookFrm::OnEdittelClick( wxCommandEvent& event )
{
    TelephoneEmailDlg dlg(this,wxID_ANY,wxT("Edit Telephone")); //create dialog
    dlg.st_value->SetLabel(wxT("Number:")); //show it
   
    long index=lv_telephones->GetFirstSelected(); //get index of the select phone
    TelephoneRow* editTel=telephone->Id(lv_telephones->GetItemData(index)); //get the TelephoneRow to edit
   
    dlg.tc_value->SetValue(editTel->number); //load the number
    dlg.tc_description->SetValue(editTel->description); //load the description

    if(dlg.ShowModal()==wxID_OK){
        editTel->number=dlg.tc_value->GetValue(); //change the number
        editTel->description=dlg.tc_description->GetValue(); //change the description
       
        editTel->Save(); //save it (it will know if it's new or not)

        Load(loaded); //reload contact
    }
}


/*!
 * wxEVT_UPDATE_UI event handler for ID_EDITTEL
 */

void ContactBookFrm::OnEdittelUpdate( wxUpdateUIEvent& event )
{
	if(lv_telephones->GetFirstSelected()<0)
		btn_editTel->Enable(false);
	else
		btn_editTel->Enable(true);
}


/*!
 * wxEVT_COMMAND_BUTTON_CLICKED event handler for ID_DELETETEL
 */

void ContactBookFrm::OnDeletetelClick( wxCommandEvent& event )
{
	long index=lv_telephones->GetFirstSelected();

	telephone->Delete(lv_telephones->GetItemData(index));
	lv_telephones->DeleteItem(index);

}

/*!
 * wxEVT_UPDATE_UI event handler for ID_DELETETEL
 */

void ContactBookFrm::OnDeletetelUpdate( wxUpdateUIEvent& event )
{
	if(lv_telephones->GetFirstSelected()<0)
		btn_deleteTel->Enable(false);
	else
		btn_deleteTel->Enable(true);
}


/*!
 * wxEVT_COMMAND_BUTTON_CLICKED event handler for ID_NEWEMAIL
 */

void ContactBookFrm::OnNewemailClick( wxCommandEvent& event )
{
	TelephoneEmailDlg dlg(this,wxID_ANY,wxT("New Email"));
	dlg.st_value->SetLabel(wxT("Email"));
	if(dlg.ShowModal()==wxID_OK){
		EmailRow* newEmail=email->New();
		newEmail->contact_id=loaded->id;
		newEmail->priority=loadedEmails->Count()+1;
		newEmail->Save();

		Load(loaded);
	}
}

/*!
 * wxEVT_COMMAND_BUTTON_CLICKED event handler for ID_EDITEMAIL
 */

void ContactBookFrm::OnEditemailClick( wxCommandEvent& event )
{
	TelephoneEmailDlg dlg(this,wxID_ANY,wxT("Edit Email"));
	dlg.st_value->SetLabel(wxT("Email:"));
	
	long index=lv_emails->GetFirstSelected();
	EmailRow* editEmail=email->Id(lv_emails->GetItemData(index));
	
	dlg.tc_value->SetValue(editEmail->email);
	dlg.tc_description->SetValue(editEmail->description);

	if(dlg.ShowModal()==wxID_OK){
		editEmail->email=dlg.tc_value->GetValue();
		editEmail->description=dlg.tc_description->GetValue();
		
		editEmail->Save();

		Load(loaded);
	}
}

/*!
 * wxEVT_UPDATE_UI event handler for ID_EDITEMAIL
 */

void ContactBookFrm::OnEditemailUpdate( wxUpdateUIEvent& event )
{
	if(lv_emails->GetFirstSelected()<0)
		btn_editEmail->Enable(false);
	else
		btn_editEmail->Enable(true);
}

/*!
 * wxEVT_COMMAND_BUTTON_CLICKED event handler for ID_DELETEEMAIL
 */

void ContactBookFrm::OnDeleteemailClick( wxCommandEvent& event )
{
	long index=lv_emails->GetFirstSelected();

	email->Delete(lv_emails->GetItemData(index));
	lv_emails->DeleteItem(index);
}

/*!
 * wxEVT_UPDATE_UI event handler for ID_DELETEEMAIL
 */

void ContactBookFrm::OnDeleteemailUpdate( wxUpdateUIEvent& event )
{
	if(lv_emails->GetFirstSelected()<0)
		btn_deleteEmail->Enable(false);
	else
		btn_deleteEmail->Enable(true);
}


/*!
 * wxEVT_COMMAND_BUTTON_CLICKED event handler for ID_APPLY
 */

void ContactBookFrm::OnApplyClick( wxCommandEvent& event )
{   
    //get the personal data
    loaded->lastName=tc_lastName->GetValue();
    loaded->firstName=tc_firstName->GetValue();
    loaded->address=tc_address->GetValue();
   
    loaded->Save(); //save the Contact
    loadedTels->SaveAll(); //save its phones, we already know they are from this contact
    loadedEmails->SaveAll(); //save its emails, we already know they are from this contact

    LoadContactList(); //Reload the contact list (for name, last name changes).
}

/*!
 * wxEVT_UPDATE_UI event handler for ID_APPLY
 */

void ContactBookFrm::OnApplyUpdate( wxUpdateUIEvent& event )
{
	if(loaded==NULL)
		btn_apply->Enable(false);
	else
		btn_apply->Enable(true);
}

/*!
 * wxEVT_COMMAND_BUTTON_CLICKED event handler for ID_CANCEL
 */

void ContactBookFrm::OnCancelClick( wxCommandEvent& event )
{
	long index=lv_contacts->GetFirstSelected();
	if(index<0)
		Load(NULL);	
	else
		Load(contact->Id(lv_contacts->GetItemData(index)));
}

/*!
 * wxEVT_UPDATE_UI event handler for ID_CANCEL
 */

void ContactBookFrm::OnCancelUpdate( wxUpdateUIEvent& event )
{
	if(loaded==NULL)
		btn_cancel->Enable(false);
	else
		btn_cancel->Enable(true);

}


void ContactBookFrm::Load(ContactRow* row){
    loaded=row; //set the loaded item to row
   
    //clear the panel
    lv_telephones->DeleteAllItems();
    lv_emails->DeleteAllItems();
    tc_lastName->SetValue(wxT(""));
    tc_firstName->SetValue(wxT(""));
    tc_address->SetValue(wxT(""));

    if(loaded==NULL) //if the loaded ContactRow* is null do nothing
        return;

        //load the personal data
    tc_lastName->SetValue(loaded->lastName);
    tc_firstName->SetValue(loaded->firstName);
    tc_address->SetValue(loaded->address);
   
       
    TelephoneRowSet* tels=loaded->GetTelephones(); //get the phones of this contact
    tels->SortBy(wxT("priority desc")); //sort them by descending priority, will reverse on insertion
   
    for(unsigned long i=0;i<tels->Count();++i){
        lv_telephones->InsertItem(0,tels->Item(i)->number);
        lv_telephones->SetItem(0,1,tels->Item(i)->description);

        lv_telephones->SetItemData(0,tels->Item(i)->id); //set the id as ItemData
    }
    loadedTels=tels; // this are now th loaded telephones

    EmailRowSet* emails=loaded->GetEmails(); //get the emails of this contact
    emails->SortBy(wxT("priority desc")); //sort them by descending priority, will reverse on insertion
   
    for(unsigned long i=0;i<emails->Count();++i){
        lv_emails->InsertItem(0,emails->Item(i)->email);
        lv_emails->SetItem(0,1,emails->Item(i)->description);

        lv_emails->SetItemData(0,emails->Item(i)->id); //set the id as ItemData
    }
    loadedEmails=emails; // this are now th loaded emails
}


void ContactBookFrm::LoadContactList(){
    lv_contacts->DeleteAllItems();
    ContactRowSet* allContacts=contact->All(); //we get all the contacts in a ContatRowSet
    allContacts->SortBy(wxT("lastName desc")); //sort the contacts, desc so we reversed the when adding them to the ListView

    for(unsigned long i=0;i<allContacts->Count();++i){ //iterate the RowSet and add all the contacts to the listview
        lv_contacts->InsertItem(0,allContacts->Item(i)->lastName);
        lv_contacts->SetItem(0,1,allContacts->Item(i)->firstName);
       
        lv_contacts->SetItemData(0,allContacts->Item(i)->id); //add the id of the contact as the ItemData.
    }
}
/*!
 * wxEVT_CLOSE_WINDOW event handler for ID_FRAME
 */

void ContactBookFrm::OnCloseWindow( wxCloseEvent& event )
{
    delete telephone; //delete the telephone active record
    delete email; //delete the email active record
    delete contact; //delete the contact active record
////@begin wxEVT_CLOSE_WINDOW event handler for ID_FRAME in ContactBookFrm.
    // Before editing this code, remove the block markers.
    event.Skip();
////@end wxEVT_CLOSE_WINDOW event handler for ID_FRAME in ContactBookFrm.
}


/*!
 * wxEVT_COMMAND_LIST_ITEM_SELECTED event handler for ID_LVCONTACTS
 */

void ContactBookFrm::OnLvcontactsSelected( wxListEvent& event )
{
    long index=lv_contacts->GetFirstSelected();
    long id=lv_contacts->GetItemData(index); //get the contact id that we set earlier
       
    Load(contact->Id(id)); //load the ContactRow* returned by contact->Id(id)

}


/*!
 * wxEVT_COMMAND_LIST_ITEM_ACTIVATED event handler for ID_LVTELEPHONES
 */

void ContactBookFrm::OnLvtelephonesItemActivated( wxListEvent& event )
{
    long index=lv_telephones->GetFirstSelected(); //get the activated phone

    ContactRow* owner=telephone->Id(lv_telephones->GetItemData(index))->GetContact(); //get the ContactRow this phone belongs to
   
    wxMessageBox(wxString::Format(wxT("This phone belongs to %s, %s."),owner->lastName,owner->firstName),wxT("Telephone")); //show message
   
}


/*!
 * wxEVT_COMMAND_LIST_ITEM_ACTIVATED event handler for ID_LVEMAILS
 */


void ContactBookFrm::OnLvemailsItemActivated( wxListEvent& event )
{
    long index=lv_emails->GetFirstSelected(); //get the activated email

    ContactRow* owner=email->Id(lv_emails->GetItemData(index))->GetContact(); //get the ContactRow this email belongs to
   
    wxMessageBox(wxString::Format(wxT("This email belongs to %s, %s."),owner->lastName,owner->firstName),wxT("Email")); //show message
}


