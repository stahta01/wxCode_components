/////////////////////////////////////////////////////////////////////////////
// Name:        tutorial_wxargapp.cpp
// Purpose:     
// Author:      Mat�as Szeftel
// Modified by: 
// Created:     30/09/2006 00:53:20
// RCS-ID:      
// Copyright:	 Mat�as Szeftel - mszeftel@yahoo.com.ar	
// Licence:      GPL v2
/////////////////////////////////////////////////////////////////////////////

#if defined(__GNUG__) && !defined(NO_GCC_PRAGMA)
#pragma implementation "tutorial_wxargapp.h"
#endif

// For compilers that support precompilation, includes "wx/wx.h".
#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
#include "wx/wx.h"
#endif

////@begin includes
////@end includes

#include "tutorial_wxargapp.h"

////@begin XPM images
////@end XPM images

/*!
 * Application instance implementation
 */

////@begin implement app
IMPLEMENT_APP( Tutorial_wxARGApp )
////@end implement app

/*!
 * Tutorial_wxARGApp type definition
 */

IMPLEMENT_CLASS( Tutorial_wxARGApp, wxApp )

/*!
 * Tutorial_wxARGApp event table definition
 */

BEGIN_EVENT_TABLE( Tutorial_wxARGApp, wxApp )

////@begin Tutorial_wxARGApp event table entries
////@end Tutorial_wxARGApp event table entries

END_EVENT_TABLE()

/*!
 * Constructor for Tutorial_wxARGApp
 */

Tutorial_wxARGApp::Tutorial_wxARGApp()
{
////@begin Tutorial_wxARGApp member initialisation
////@end Tutorial_wxARGApp member initialisation
}

/*!
 * Initialisation for Tutorial_wxARGApp
 */

bool Tutorial_wxARGApp::OnInit()
{    
////@begin Tutorial_wxARGApp initialisation
	// Remove the comment markers above and below this block
	// to make permanent changes to the code.

#if wxUSE_XPM
	wxImage::AddHandler(new wxXPMHandler);
#endif
#if wxUSE_LIBPNG
	wxImage::AddHandler(new wxPNGHandler);
#endif
#if wxUSE_LIBJPEG
	wxImage::AddHandler(new wxJPEGHandler);
#endif
#if wxUSE_GIF
	wxImage::AddHandler(new wxGIFHandler);
#endif
	ContactBookFrm* mainWindow = new ContactBookFrm( NULL, ID_FRAME );
	mainWindow->Show(true);
////@end Tutorial_wxARGApp initialisation

    return true;
}

/*!
 * Cleanup for Tutorial_wxARGApp
 */
int Tutorial_wxARGApp::OnExit()
{    
////@begin Tutorial_wxARGApp cleanup
	return wxApp::OnExit();
////@end Tutorial_wxARGApp cleanup
}

